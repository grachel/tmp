# -*- coding: utf-8 -*-
import json
import os
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import resolveurl


class replacement_stderr(sys.stderr.__class__):
    def isatty(self): return False


sys.stderr.__class__ = replacement_stderr


def notice(content):
    log(content, xbmc.LOGINFO)


def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)


# python embedded (as used in kodi) has a known bug for second calls of strptime.
# The python bug is docmumented here https://bugs.python.org/issue27400
# The following workaround patch is borrowed from https://forum.kodi.tv/showthread.php?tid=112916&pid=2914578#pid2914578
def patch_strptime():
    import datetime

    # fix for datatetime.strptime returns None
    class proxydt(datetime.datetime):
        @staticmethod
        def strptime(date_string, format):
            import time
            return datetime.datetime(*(time.strptime(date_string, format)[0:6]))

    datetime.datetime = proxydt


def show_error_notification(message):
    xbmcgui.Dialog().notification("SendToKodi", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)


# Get the plugin url in plugin:// notation.
__url__ = sys.argv[0]
# Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])


def get_params():
    result = {}
    paramstring = sys.argv[2]
    additionalParamsIndex = paramstring.find(' ')
    if additionalParamsIndex == -1:
        result['url'] = paramstring[1:]
    else:
        result['url'] = paramstring[1:additionalParamsIndex]
    return result


# patch broken strptime (see above)
patch_strptime()
params = get_params()

url = str(params['url'])

progress = xbmcgui.DialogProgressBG()
progress.create("Resolving " + url)
try:
    notice(url)
    result = resolveurl.resolve(url)
    notice(result)
except:
    progress.close()
    show_error_notification("Could not resolve the url, check the log for more info")
    import traceback

    log(msg=traceback.format_exc(), level=xbmc.LOGERROR)
    exit()
progress.close()

if result:
    xbmcplugin.setResolvedUrl(__handle__, True, xbmcgui.ListItem(path=result))
